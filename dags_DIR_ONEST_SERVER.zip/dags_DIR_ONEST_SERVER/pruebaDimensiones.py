
#Leemos las dimensiones del almacen y las almacenamos en diferentes variables
import json
given_file = open('dimensionesAlmacen.txt', 'r')

dimAlmacenRawDict = given_file.readlines()

for line in dimAlmacenRawDict:
    for c in line:
        if c.isdigit() == True:
            print('Integer found : {}'.format(c))

given_file.close()


DimAlmacen=json.loads(dimAlmacenRawDict[0].replace("\'", "\""))

#y_inf=DimAlmacen["y_inferior"]

y_sup=int(DimAlmacen["y_superior"])



