import os
AIRFLOW_HOME = os.getenv('AIRFLOW_HOME')
print(AIRFLOW_HOME)
